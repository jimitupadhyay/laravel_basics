<?php $__env->startSection('body'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Profile</div>

                <div class="panel-body">
                    <p>My age is <?php echo e($age); ?>

					</p>
					<p>My age is <?php echo $age; ?>
					</p>
					<p><?php echo 'Hello ' . 'Jimit'; ?>
					</p>
					My Email Id is <?php echo e($auth->email); ?>

					
					My Name is <?php echo e($auth->name); ?>

					
					Marrital status <?php echo e($married); ?>

					
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>