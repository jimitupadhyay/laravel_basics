@extends('layouts.master')

@section('title')
	This is Title
@endsection

@section('body')
	THis is body from bladetest
@endsection