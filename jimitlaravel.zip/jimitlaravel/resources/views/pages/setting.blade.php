@extends('layouts.master')

@section('body')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Profile</div>

                <div class="panel-body">
                    My age is {{ $age }}

					My Email Id is {{ $auth->email }}
					
					My Name is {{ $auth->name }}
					
					Marrital status {{ $married }}
					
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
