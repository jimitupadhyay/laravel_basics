@extends('layouts.master')

@section('body')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Profile</div>

                <div class="panel-body">
                    <p>My age is {{ $age }}
					</p>
					<p>My age is @age([1990,10,10])
					</p>
					<p>@sayHello('Jimit')
					</p>
					My Email Id is {{ $auth->email }}
					
					My Name is {{ $auth->name }}
					
					Marrital status {{ $married }}
					
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
