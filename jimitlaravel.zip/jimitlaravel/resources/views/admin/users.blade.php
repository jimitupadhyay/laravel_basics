@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
			<span>Total {{ $users->total() }} User</span>
			</br>
			<span>In this page, showing {{ $users->count() }} Users </span>
            <ul class="list-group">
				@forelse($users as $user)
					<li class="list-group-item" style="margin-top:20px">
						<span>{{ $user->name }}</span>
						
						<span class="pull-right clearfix">{{ $user->created_at->diffForHumans() }}
								<button class="btn btn-primary">
									Follow
								</button>
						</span>
					</li>
				@empty
					No User Found
				@endforelse
				
			</ul>
			{{ $users->links() }}
        </div>
    </div>
</div>
@endsection
