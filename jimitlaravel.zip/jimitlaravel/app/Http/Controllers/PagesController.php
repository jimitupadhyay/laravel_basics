<?php

namespace App\Http\Controllers;

use View;
use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function index()
	{
		if(View::exists('pages.index'))
			return view('pages.index')->with('name','Jimit');
		else
			return 'No Such VIew Found';
	}
	
	public function profile()
	{
		return view('pages.profile');
	}
	
	public function setting()
	{
		return view('pages.setting');
	}
	public function blade()
	{
		return view('blade.bladetest');
	}
	
}
