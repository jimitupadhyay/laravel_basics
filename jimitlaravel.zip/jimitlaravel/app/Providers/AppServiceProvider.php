<?php

namespace App\Providers;

use View;
use Auth;
use Carbon\Carbon;
use Illuminate\Support\ServiceProvider;
use Blade;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
		Blade::directive('age',function($expression){
			$data = json_encode($expression);
			$year = $data[0];
			$month = $data[1];
			$day = $data[2];
			$age = Carbon::createFromDate(1990,10,10)->age;
			return '<?php echo $age; ?>';
		});
		
		Blade::directive('sayHello', function($expression1){
			return "<?php echo 'Hello ' . $expression1; ?>";
		});
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //register VS boot
		$myage = Carbon::createFromDate(1990,10,10)->age;
		
		View::share('age',$myage);
		
        View::share('key','value');
		
		View::composer('*',function($view){
			$view->with('auth',Auth::User());
		});
    }
}
